function getValue(num){
var inp = document.getElementById("input")
inp.value += num
}



function calc(){
    var inp = document.getElementById("input")
    inp.value = eval(inp.value)
}


function cleaner(){
    var inp = document.getElementById("input");
    inp.value = "";
}


function cancel(){
    var inp = document.getElementById("input");
    inp.value = inp.value.slice(0, -1)


}

